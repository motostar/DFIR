SA_plaso-app-for-splunk v0.2
----------------------------	
	
	Author: Dave Herrald 
	Version/Date: 0.1 June 7, 2016

Updates 
----------------------------

	0.2
	-----
	Merged pull request 1, adding ad-hoc search to the colorized super timeline view.


Using this app
----------------------------


Support
----------------------------

	This is a community supported TA. As such, post to answers.splunk.com
	and reference it. Someone should be with you shortly.
